.. pyBarcode documentation master file, created by
   sphinx-quickstart on Fri Mar 12 13:29:48 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

pyBarcode's Documentation
=========================

Contents
--------

.. toctree::
   :maxdepth: 2

   barcode
   codes
   writers/index
   license

Indices and tables
==================

* :ref:`search`

Latest version
==============

You can always download the latest release
`here <https://code.google.com/p/python-barcode/downloads/>`_.

Related Links
=============

:Project page: https://code.google.com/p/python-barcode/

:Issues: https://code.google.com/p/python-barcode/issues/

:Wiki: https://code.google.com/p/python-barcode/w/

