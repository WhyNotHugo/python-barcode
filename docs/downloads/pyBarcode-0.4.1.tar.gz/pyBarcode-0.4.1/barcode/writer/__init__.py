# -*- coding: utf-8 -*-

"""
This package provides the basic writers shipped with pyBarcode.
"""
